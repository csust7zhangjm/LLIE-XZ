from easydict import EasyDict
Cfg = EasyDict()
Cfg.gpu_id = '0'

# whether to resume from a checkpoint
Cfg.resume = False
# Cfg.resume = True
# Cfg.resume_tar = '.\result_LOL\LOL.pth'

Cfg.dataset_dir = 'D:\Postgraduate\pycharm\datasets\LOL'

Cfg.train_input_dir = Cfg.dataset_dir + '/our485/'
Cfg.test_input_dir = Cfg.dataset_dir + '/eval15/'

# all the results will be under result_dir
Cfg.result_dir = './RESULT/'


# training batch and size
Cfg.bs = 4
Cfg.ps = 256   # patch size for training
Cfg.test_freq = 10
Cfg.model_save_freq = 10 # frequency to save the model
Cfg.training_epoch = 301 #401
Cfg.learning_rate = 1e-4 #1e-4
Cfg.scheduler_gamma = 0.5 #0.5

#
# # loss weightings for each term
Cfg.mae_loss_w = 1  # 0.85
Cfg.ms_ssim_loss_w = 0.5  # 0.15

# testing parameters
Cfg.save_test_image = True

Cfg.RASA_cfg = dict(
    atrous_rates=[1, 3, 5],
    act_layer='nn.SiLU(True)',
    init='kaiming',
    r_num=2,
)

