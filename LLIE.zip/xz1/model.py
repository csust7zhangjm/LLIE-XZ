from timm.models.layers import DropPath, to_2tuple, trunc_normal_
import math
from einops import rearrange
from cfg import Cfg
from segformer import *

class ds_conv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1,
                 dilation=[1, 3, 5], groups=1, bias=True,
                 act_layer='nn.SiLU(True)', init='kaiming'):
        super().__init__()
        assert in_planes % groups == 0
        assert kernel_size == 3, 'only support kernel size 3 now'
        self.in_planes = in_planes
        self.out_planes = out_planes
        self.kernel_size = kernel_size
        self.stride = stride
        self.dilation = dilation
        self.groups = groups
        self.with_bias = bias

        self.weight = nn.Parameter(torch.randn(out_planes, in_planes // groups, kernel_size, kernel_size),
                                   requires_grad=True)
        if bias:
            self.bias = nn.Parameter(torch.Tensor(out_planes))
        else:
            self.bias = None
        self.act = eval(act_layer)
        self.init = init
        self._initialize_weights()

    def _initialize_weights(self):
        if self.init == 'dirac':
            nn.init.dirac_(self.weight, self.groups)
        elif self.init == 'kaiming':
            nn.init.kaiming_uniform_(self.weight)
        else:
            raise NotImplementedError
        if self.with_bias:
            if self.init == 'dirac':
                nn.init.constant_(self.bias, 0.)
            elif self.init == 'kaiming':
                bound = self.groups / (self.kernel_size ** 2 * self.in_planes)
                bound = math.sqrt(bound)
                nn.init.uniform_(self.bias, -bound, bound)
            else:
                raise NotImplementedError

    def forward(self, x):
        output = 0
        for dil in self.dilation:
            output += self.act(
                F.conv2d(
                    x, weight=self.weight, bias=self.bias, stride=self.stride, padding=dil,
                    dilation=dil, groups=self.groups,
                )
            )
        return output

class Double_Conv2d(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(Double_Conv2d, self).__init__()
        self.double_conv2d = torch.nn.Sequential(
            nn.Conv2d(
                in_channels=in_channel,
                out_channels=out_channel,
                kernel_size=3,
                padding=1), nn.LeakyReLU(0.2),
            nn.Conv2d(
                in_channels=out_channel,
                out_channels=out_channel,
                kernel_size=3,
                padding=1), nn.LeakyReLU(0.2))

    def forward(self, x):
        return self.double_conv2d(x)

class CSA(nn.Module):
    def __init__(self, in_dim, out_dim, num_heads, kernel_size=3, padding=1, stride=2,
                 qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        head_dim = out_dim // num_heads
        self.num_heads = num_heads
        self.kernel_size = kernel_size
        self.padding = padding
        self.stride = stride
        self.scale = qk_scale or head_dim ** -0.5

        self.attn = nn.Linear(in_dim, kernel_size ** 4 * num_heads)
        self.attn_drop = nn.Dropout(attn_drop)

        self.unfold = nn.Unfold(kernel_size=kernel_size, padding=padding, stride=stride)
        self.pool = nn.AvgPool2d(kernel_size=stride, stride=stride, ceil_mode=True)

        self.csa_group = 1
        assert out_dim % self.csa_group == 0
        self.weight = nn.Conv2d(
            self.kernel_size * self.kernel_size * out_dim,
            self.kernel_size * self.kernel_size * out_dim,
            1,
            stride=1, padding=0, dilation=1,
            groups=self.kernel_size * self.kernel_size * self.csa_group,
            bias=qkv_bias,
        )
        assert qkv_bias == False
        fan_out = self.kernel_size * self.kernel_size * self.out_dim
        fan_out //= self.csa_group
        self.weight.weight.data.normal_(0, math.sqrt(2.0 / fan_out))  # init

        self.proj = nn.Linear(out_dim, out_dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x, v=None):
        # x= x.permute(0, 2, 3, 1)
        B, H, W, _ = x.shape
        h, w = math.ceil(H / self.stride), math.ceil(W / self.stride)

        attn = self.pool(x.permute(0, 3, 1, 2)).permute(0, 2, 3, 1)

        attn = self.attn(attn).reshape(
            B, h * w, self.num_heads, self.kernel_size * self.kernel_size,
               self.kernel_size * self.kernel_size).permute(0, 2, 1, 3, 4)  # B,H,N,kxk,kxk

        attn = attn * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        v = x.permute(0, 3, 1, 2)  # B,C,H, W
        v = self.unfold(v).reshape(
            B, self.out_dim, self.kernel_size * self.kernel_size, h * w
        ).permute(0, 3, 2, 1).reshape(B * h * w, self.kernel_size * self.kernel_size * self.out_dim, 1, 1)
        v = self.weight(v)
        v = v.reshape(B, h * w, self.kernel_size * self.kernel_size, self.num_heads,
                      self.out_dim // self.num_heads).permute(0, 3, 1, 2, 4).contiguous()  # B,H,N,kxk,C/H

        x = (attn @ v).permute(0, 1, 4, 3, 2)
        x = x.reshape(B, self.out_dim * self.kernel_size * self.kernel_size, h * w)
        x = F.fold(x, output_size=(H, W), kernel_size=self.kernel_size,
                   padding=self.padding, stride=self.stride)

        x = self.proj(x.permute(0, 2, 3, 1))
        # x = self.proj(x)
        x = self.proj_drop(x)
        return x

class Attention(nn.Module):
    def __init__(
            self,
            dim, num_heads=8, qkv_bias=False,
            qk_scale=None, attn_drop=0.,
            proj_drop=0.,
            rasa_cfg=None, sr_ratio=1,
            linear=False,

    ):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

        self.linear = linear
        self.rasa_cfg = rasa_cfg
        self.use_rasa = rasa_cfg is not None
        self.sr_ratio = sr_ratio

        if not linear:
            if sr_ratio > 1:
                self.sr = nn.Conv2d(dim, dim, kernel_size=sr_ratio, stride=sr_ratio)
                self.norm = nn.LayerNorm(dim)
        else:
            self.pool = nn.AdaptiveAvgPool2d(7)
            self.sr = nn.Conv2d(dim, dim, kernel_size=1, stride=1)
            self.norm = nn.LayerNorm(dim)
            self.act = nn.GELU()

        if self.use_rasa:
            if self.rasa_cfg.atrous_rates is not None:
                self.ds = ds_conv2d(
                    dim, dim, kernel_size=3, stride=1,
                    dilation=self.rasa_cfg.atrous_rates, groups=dim, bias=qkv_bias,
                    act_layer=self.rasa_cfg.act_layer, init=self.rasa_cfg.init,
                )
            if self.rasa_cfg.r_num > 1:
                self.silu = nn.SiLU(True)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def _inner_attention(self, x):
        B, H, W, C = x.shape
        q = self.q(x).reshape(B, H * W, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        if self.use_rasa:
            if self.rasa_cfg.atrous_rates is not None:
                q = q.permute(0, 1, 3, 2).reshape(B, self.dim, H, W).contiguous()
                q = self.ds(q)
                q = q.reshape(B, self.num_heads, self.dim // self.num_heads, H * W).permute(0, 1, 3, 2).contiguous()

        if not self.linear:
            if self.sr_ratio > 1:
                x_ = x.permute(0, 3, 1, 2)
                x_ = self.sr(x_).permute(0, 2, 3, 1)
                x_ = self.norm(x_)
                kv = self.kv(x_).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
            else:
                kv = self.kv(x).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        else:
            raise NotImplementedError

        k, v = kv[0], kv[1]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = (attn @ v).transpose(1, 2).reshape(B, H, W, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x

    def forward(self, x):
        if self.use_rasa:
            x_in = x
            x = self._inner_attention(x)
            if self.rasa_cfg.r_num > 1:
                x = self.silu(x)
            for _ in range(self.rasa_cfg.r_num - 1):
                x = x + x_in
                x_in = x
                x = self._inner_attention(x)
                x = self.silu(x)
        else:
            x = self._inner_attention(x)
        return x

##  Mixed-Scale Feed-forward Network (MSFN)
class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()

        hidden_features = int(dim * ffn_expansion_factor)

        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)

        self.dwconv3x3 = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3, stride=1, padding=1,
                                   groups=hidden_features * 2, bias=bias)
        self.dwconv5x5 = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=5, stride=1, padding=2,
                                   groups=hidden_features * 2, bias=bias)
        self.relu3 = nn.ReLU()
        self.relu5 = nn.ReLU()

        self.dwconv3x3_1 = nn.Conv2d(hidden_features * 2, hidden_features, kernel_size=3, stride=1, padding=1,
                                     groups=hidden_features, bias=bias)
        self.dwconv5x5_1 = nn.Conv2d(hidden_features * 2, hidden_features, kernel_size=5, stride=1, padding=2,
                                     groups=hidden_features, bias=bias)

        self.relu3_1 = nn.ReLU()
        self.relu5_1 = nn.ReLU()

        self.project_out = nn.Conv2d(hidden_features * 2, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = x.permute(0, 3, 1, 2)
        x = self.project_in(x)
        x1_3, x2_3 = self.relu3(self.dwconv3x3(x)).chunk(2, dim=1)
        x1_5, x2_5 = self.relu5(self.dwconv5x5(x)).chunk(2, dim=1)

        x1 = torch.cat([x1_3, x1_5], dim=1)
        x2 = torch.cat([x2_3, x2_5], dim=1)

        x1 = self.relu3_1(self.dwconv3x3_1(x1))
        x2 = self.relu5_1(self.dwconv5x5_1(x2))

        x = torch.cat([x1, x2], dim=1)

        x = self.project_out(x).permute(0, 2, 3, 1)

        return x

class Transformer_block(nn.Module):
    def __init__(self, dim=256,
                 num_heads=1, attn_drop=0.,
                 drop_path=0., sa_layer='sa', rasa_cfg=None, sr_ratio=1, norm_layer=nn.LayerNorm,
                 qkv_bias=False, qk_scale=None, ffn_expansion_factor=1, bias=False):
        super().__init__()
        self.norm1 = norm_layer(dim)
        if sa_layer == 'csa':
            self.attn = CSA(
                dim, dim, num_heads,
                qkv_bias=qkv_bias, qk_scale=qk_scale,
                attn_drop=attn_drop)
        elif sa_layer in ['rasa', 'sa']:
            self.attn = Attention(
                dim, num_heads=num_heads,
                qkv_bias=qkv_bias, qk_scale=qk_scale,
                attn_drop=attn_drop, rasa_cfg=rasa_cfg, sr_ratio=sr_ratio)
        else:
            raise NotImplementedError
        self.drop_path = DropPath(
            drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)
        self.ffn = FeedForward(
            dim=dim,
            ffn_expansion_factor=ffn_expansion_factor,
            bias=bias)

    def forward(self, x):
        x = x + self.drop_path(self.attn(self.norm1(x)))
        x = x + self.drop_path(self.ffn(self.norm2(x)))  # MLP->MSFN
        return x

# ViT中使用patch merge，可以轻易地将特征张量缩小。但是此过程最初旨在组合非重叠的图像或特征块，不能保持patch周围的局部连续性。
# 因此SegFormer使用Overlap Patch Merge，进行特征融合从而取得分层的特征。
# 在具体实现中，是使用卷积操作进行的Patch Merge，即通过设计卷积核大小和步幅，来降低特征分辨率。
# 同时卷积应该也实现了Embedding操作，将其投射到给定维度。

# 在SegFormer中，为了保持patch周围之间的局部连续性，使用了重叠的patch。
# 这与之前ViT和PVT做patch embedding时每个patch是独立的不同，这样可以保证局部连续性
class OverlapPatchEmbed(nn.Module):
    def __init__(self, patch_size=7, stride=4, in_chans=3, embed_dim=48):
        super().__init__()
        patch_size = to_2tuple(patch_size)
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride,
                              padding=(patch_size[0] // 2, patch_size[1] // 2))
        self.norm = nn.LayerNorm(embed_dim)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x):
        if self.patch_size[0] == 7:
            x = self.proj(x)
            x = x.permute(0, 2, 3, 1)
            x = self.norm(x)
        else:
            x = x.permute(0, 3, 1, 2)
            x = self.proj(x)
            x = x.permute(0, 2, 3, 1)
            x = self.norm(x)
        return x

# Swin-Unet
class PatchExpand(nn.Module):
    def __init__(self, dim, dim_scale=2, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.expand = nn.Linear(dim, 2 * dim, bias=False) if dim_scale == 2 else nn.Identity()
        self.norm = norm_layer(dim // dim_scale)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        B, H, W, C = x.shape
        x = x.view(B, H * W, C)
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=2, p2=2, c=C // 4)
        x = x.view(B, H * 2, W * 2, C // 4)
        x = self.norm(x)

        return x

class FinalPatchExpand_X4(nn.Module):
    def __init__(self, dim, dim_scale=4, norm_layer=nn.LayerNorm):
        super().__init__()
        self.dim = dim
        self.dim_scale = dim_scale
        self.expand = nn.Linear(dim, 16 * dim, bias=False)
        self.output_dim = dim
        self.norm = norm_layer(self.output_dim)

    def forward(self, x):
        """
        x: B, H*W, C
        """
        B, H, W, C = x.shape
        x = x.view(B, H * W, C)
        x = self.expand(x)
        B, L, C = x.shape
        assert L == H * W, "input feature has wrong size"

        x = x.view(B, H, W, C)
        x = rearrange(x, 'b h w (p1 p2 c)-> b (h p1) (w p2) c', p1=self.dim_scale, p2=self.dim_scale,
                      c=C // (self.dim_scale ** 2))
        x = x.view(B, H * 4, W * 4, self.output_dim)
        x = self.norm(x)

        return x

class Cross_Attention(nn.Module):
    def __init__(self, key_channels, value_channels, head_count=1):
        super().__init__()
        self.key_channels = key_channels
        self.head_count = head_count
        self.value_channels = value_channels
        self.reprojection = nn.Conv2d(value_channels, 2 * value_channels, 1)
        self.norm = nn.LayerNorm(2 * value_channels)

        self.attn1 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn2 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn3 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn4 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)
        self.attn5 = torch.nn.Parameter(torch.tensor([0.2]), requires_grad=True)

    # x2 should be higher-level representation than x1
    def forward(self, x1, x2, H, W,maskv):
        B, N, D = x1.size()  # (Batch, Tokens, Embedding dim)
        # Re-arrange into a (Batch, Embedding dim, Tokens)
        keys = x2.transpose(1, 2)
        queries = x2.transpose(1, 2)
        values = x1.transpose(1, 2)
        head_key_channels = self.key_channels // self.head_count
        head_value_channels = self.value_channels // self.head_count

        attended_values = []
        for i in range(self.head_count):
            key = F.softmax(keys[:, i * head_key_channels : (i + 1) * head_key_channels, :], dim=2)
            query = F.softmax(queries[:, i * head_key_channels : (i + 1) * head_key_channels, :], dim=1)
            value = values[:, i * head_value_channels : (i + 1) * head_value_channels, :]
            context = key @ value.transpose(1, 2)  # dk*dv
            mask1 = torch.zeros(B, D, D, device=x1.device, requires_grad=False)
            mask2 = torch.zeros(B, D, D, device=x1.device, requires_grad=False)
            mask3 = torch.zeros(B, D, D, device=x1.device, requires_grad=False)
            mask4 = torch.zeros(B, D, D, device=x1.device, requires_grad=False)

            index = torch.topk(context, k=int(D * 1 / 2), dim=-1, largest=True)[1]
            mask1.scatter_(-1, index, 1.)
            attn1 = torch.where(mask1 > 0, context, torch.full_like(context, float('-inf')))

            index = torch.topk(context, k=int(D * 2 / 3), dim=-1, largest=True)[1]
            mask2.scatter_(-1, index, 1.)
            attn2 = torch.where(mask2 > 0, context, torch.full_like(context, float('-inf')))

            index = torch.topk(context, k=int(D * 3 / 4), dim=-1, largest=True)[1]
            mask3.scatter_(-1, index, 1.)
            attn3 = torch.where(mask3 > 0, context, torch.full_like(context, float('-inf')))

            index = torch.topk(context, k=int(D * 4 / 5), dim=-1, largest=True)[1]
            mask4.scatter_(-1, index, 1.)
            attn4 = torch.where(mask4 > 0, context, torch.full_like(context, float('-inf')))

            attn5 = maskv

            attn1 = attn1.softmax(dim=-1)
            attn2 = attn2.softmax(dim=-1)
            attn3 = attn3.softmax(dim=-1)
            attn4 = attn4.softmax(dim=-1)
            attn5 = attn5.softmax(dim=-1)



            out1 = (attn1 @ query)
            out2 = (attn2 @ query)
            out3 = (attn3 @ query)
            out4 = (attn4 @ query)
            out5 = (attn5 @ query)

            attended_value = out1 * self.attn1 + out2 * self.attn2 + out3 * self.attn3 + out4 * self.attn4 + out5 * self.attn5
            attended_values.append(attended_value)


        aggregated_values = torch.cat(attended_values, dim=1).reshape(B, D, H, W)

        reprojected_value = self.reprojection(aggregated_values).reshape(B, 2 * D, N).permute(0, 2, 1)
        reprojected_value = self.norm(reprojected_value)

        return reprojected_value

class CrossAttentionBlock(nn.Module):
    """
    Input ->    x1:[B, N, D] - N = H*W
                x2:[B, N, D]
    Output -> y:[B, N, D]
    D is half the size of the concatenated input (x1 from a lower level and x2 from the skip connection)
    """
    def __init__(self, in_dim, key_dim, value_dim,head_count=1):
        super().__init__()
        self.norm1 = nn.LayerNorm(in_dim)
        self.attn = Cross_Attention(key_dim, value_dim, head_count=head_count)
        self.norm2 = nn.LayerNorm((in_dim*2))
        self.mlp = MixFFN_skip(int(in_dim*2) , int(in_dim * 4))
        self.channel_att = SELayer(channel=int(in_dim*2))

    def forward(self, x1: torch.Tensor, x2: torch.Tensor,maskv) -> torch.Tensor:
        B,H,W,C = x1.shape
        x1 = x1.view(B,H*W,C)
        x2 = x2.view(B,H*W,C)
        norm_1 = self.norm1(x1)
        norm_2 = self.norm1(x2)
        attn = self.attn(norm_1, norm_2, H, W,maskv)
        residual = torch.cat([x1, x2], dim=2)
        tx = residual + attn
        mx = tx + self.mlp(self.norm2(tx),H,W)
        cx = mx.view(B, H, W, 2 * C).permute(0, 3, 1, 2)
        cx = self.channel_att(cx)
        return cx

class SELayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SELayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // reduction, channel, bias=False),
            nn.Sigmoid()
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c) #对应Squeeze操作
        y = self.fc(y).view(b, c, 1, 1) #对应Excitation操作
        return x * y.expand_as(x)


def max_entropy_gamma_correction(v: torch.Tensor) -> torch.Tensor:
    # 获取批量大小
    batch_size = v.shape[0]

    # 初始化输出张量
    v_corrected = torch.empty_like(v)

    # 遍历批量中的每个 V 通道分量
    for i in range(batch_size):
        # 获取当前 V 通道分量
        v_current = v[i]

        # 计算 V 通道分量的直方图
        hist = torch.histc(v_current.to(torch.float32), bins=256, min=0, max=1)

        # 归一化直方图
        hist = hist / hist.sum()

        # 初始化最大熵和最佳伽马值
        max_entropy = 0
        best_gamma = 1

        # 遍历可能的伽马值
        for gamma in torch.arange(0.1, 1 , 0.1):
            # 计算伽马校正后的 V 通道直方图
            corrected_hist = torch.pow(torch.linspace(0, 1, 256), gamma)
            corrected_hist = torch.round(corrected_hist * 255).to(torch.int64)
            corrected_hist = hist[corrected_hist]

            # 计算校正后的 V 通道直方图的熵
            entropy = -torch.sum(corrected_hist * torch.log2(corrected_hist + 1e-12))

            # 更新最大熵和最佳伽马值
            if entropy > max_entropy:
                max_entropy = entropy
                best_gamma = gamma

        # 使用最佳伽马值对当前 V 通道分量进行伽马校正
        v_corrected_current = torch.pow(v_current, best_gamma)

        # 将校正后的 V 通道分量存储到输出张量中
        v_corrected[i] = v_corrected_current

    return v_corrected

class LLIE(nn.Module):
    def __init__(self,
                 inp_channels=3,
                 out_channels=3,
                 dim=[64, 128, 256, 512],
                 num_blocks=[2, 2, 2, 2],
                 heads=[1, 2, 4, 8],
                 sr_ratios=[8, 4, 2, 1],
                 patch_size=[7, 3, 3, 3],
                 stride=[4, 2, 2, 2],
                 qkv_bias=False,
                 qk_scale=None,
                 ):
        super(LLIE, self).__init__()

        self.patch_embed0_1 = OverlapPatchEmbed(patch_size=patch_size[0], stride=stride[0], in_chans=inp_channels,
                                                embed_dim=dim[0])

        self.encoder_level1 = nn.Sequential(*[
            Transformer_block(dim=dim[0],
                              num_heads=heads[0],
                              sa_layer='csa',
                              rasa_cfg=None,  # I am here
                              sr_ratio=sr_ratios[0],
                              qkv_bias=qkv_bias, qk_scale=qk_scale,
                              ffn_expansion_factor=2.66,
                              attn_drop=0) for i in range(num_blocks[0])])

        self.patch_embed1_2 = OverlapPatchEmbed(patch_size=patch_size[1], stride=stride[1], in_chans=dim[0],
                                                embed_dim=dim[1])  ## From Level 1 to Level 2
        self.encoder_level2 = nn.Sequential(*[
            Transformer_block(dim=dim[1],
                              num_heads=heads[1],
                              sa_layer='rasa',
                              rasa_cfg=Cfg.RASA_cfg,  # I am here
                              sr_ratio=sr_ratios[1],
                              qkv_bias=qkv_bias, qk_scale=qk_scale,
                              ffn_expansion_factor=2.66,
                              attn_drop=0) for i in range(num_blocks[1])])

        self.patch_embed2_3 = OverlapPatchEmbed(patch_size=patch_size[2], stride=stride[2], in_chans=dim[1],
                                                embed_dim=dim[2])  ## From Level 2 to Level 3
        self.encoder_level3 = nn.Sequential(*[
            Transformer_block(dim=dim[2],
                              num_heads=heads[2],
                              sa_layer='rasa',
                              rasa_cfg=Cfg.RASA_cfg,  # I am here
                              sr_ratio=sr_ratios[2],
                              qkv_bias=qkv_bias, qk_scale=qk_scale,
                              ffn_expansion_factor=2.66,
                              attn_drop=0) for i in range(num_blocks[2])])

        self.patch_embed3_4 = OverlapPatchEmbed(patch_size=patch_size[3], stride=stride[3], in_chans=dim[2],
                                                embed_dim=dim[3])  ## From Level 3 to Level 4
        self.latent = nn.Sequential(*[
            Transformer_block(dim=dim[3],
                              num_heads=heads[3],
                              sa_layer='rasa',
                              rasa_cfg=Cfg.RASA_cfg,  # I am here
                              sr_ratio=sr_ratios[3],
                              qkv_bias=qkv_bias, qk_scale=qk_scale,
                              ffn_expansion_factor=2.66,
                              attn_drop=0) for i in range(num_blocks[3])])

        self.fuse3 = CrossAttentionBlock(dim[2],dim[2],dim[2])
        self.fuse2 = CrossAttentionBlock(dim[1],dim[1],dim[1])
        self.fuse1 = CrossAttentionBlock(dim[0],dim[0],dim[0])

        self.up4_3 = PatchExpand(dim=dim[3])  ## From Level 4 to Level 3
        self.decoder3 = Double_Conv2d(dim[3], dim[2])

        self.up3_2 = PatchExpand(dim=dim[2])  ## From Level 3 to Level 2
        self.decoder2 = Double_Conv2d(dim[2], dim[1])

        self.up2_1 = PatchExpand(dim=dim[1])  ## From Level 2 to Level 1
        self.decoder1 = Double_Conv2d(dim[1], dim[0])

        self.up1_0 = FinalPatchExpand_X4(dim=dim[0])

        self.output = nn.Conv2d(int(dim[0]), out_channels, kernel_size=3, stride=1, padding=1, bias=False)

    def forward(self, inp_img,maskv):
        # Encoder
        B,H,W,_= maskv.shape
        maskv = maskv.permute(0,3,1,2)
        mask_max = torch.max(maskv.view(B, -1), dim=1)[0]
        mask_max = mask_max.view(B, 1, 1, 1)
        mask_max = mask_max.repeat(1, 1, H, W)
        mask = maskv * 1.0 / (mask_max + 0.0001)
        mask = torch.clamp(mask, min=0, max=1.0)
        mask = max_entropy_gamma_correction(mask)

        mask = mask.float().squeeze(1)
        maskv2 = F.interpolate(mask.unsqueeze(0), size=256, mode='nearest').squeeze(0)
        maskv3 = F.interpolate(mask.unsqueeze(0), size=128, mode='nearest').squeeze(0)
        maskv4 = F.interpolate(mask.unsqueeze(0), size=64, mode='nearest').squeeze(0)

        inp_enc_level1 = self.patch_embed0_1(inp_img)#B,H,W,C
        out_enc_level1 = self.encoder_level1(inp_enc_level1)

        inp_enc_level2 = self.patch_embed1_2(out_enc_level1)
        out_enc_level2 = self.encoder_level2(inp_enc_level2)

        inp_enc_level3 = self.patch_embed2_3(out_enc_level2)
        out_enc_level3 = self.encoder_level3(inp_enc_level3)

        inp_enc_level4 = self.patch_embed3_4(out_enc_level3)
        latent = self.latent(inp_enc_level4)

        ####Decoder
        # [B,H,W,C]
        # 在通道上进行cat
        # decoder use conv
        inp_dec_level3 = self.up4_3(latent)
        inp_dec_level3= self.fuse3(inp_dec_level3, out_enc_level3,maskv2)
        out_dec_level3 = self.decoder3(inp_dec_level3)
        out_dec_level3 = out_dec_level3.permute(0, 2, 3, 1)

        inp_dec_level2 = self.up3_2(out_dec_level3)
        inp_dec_level2 = self.fuse2(inp_dec_level2, out_enc_level2,maskv3)
        out_dec_level2 = self.decoder2(inp_dec_level2)
        out_dec_level2 = out_dec_level2.permute(0, 2, 3, 1)

        inp_dec_level1 = self.up2_1(out_dec_level2)
        inp_dec_level1 = self.fuse1(inp_dec_level1, out_enc_level1,maskv4)
        out_dec_level1 = self.decoder1(inp_dec_level1)
        out_dec_level1 = out_dec_level1.permute(0, 2, 3, 1)

        # 分辨率x4,变回输入大小
        inp_dec_level0 = self.up1_0(out_dec_level1)
        inp_dec_level0 = inp_dec_level0.permute(0, 3, 1, 2)

        out_dec_level0 = self.output(inp_dec_level0) + inp_img
        return out_dec_level0

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    model = LLIE().cuda()
    f_u = model.cuda()
    print('total parameters:', sum(param.numel() for param in f_u.parameters()))
    x = torch.randn(2, 3, 512, 512).to(device)
    mask =  torch.randn(2, 512, 512,1).to(device)
    out = model(x,mask)
    print(out.shape)

