import os
import time
from datetime import datetime
import numpy as np
import torch
from loguru import logger
from torch import optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import utils
from cfg import Cfg
from dataloader_gray import build_Dataset_list_txt, Dataset
from model import LLIE

def main():
    # logging to text file
    dt_string = datetime.now().strftime('%d%m%Y_%H%M%S')
    logger.add(f'{Cfg.result_dir}/{dt_string}_console.log', format='{time:YYYY-MM-DD at HH:mm:ss} | {level} | \
                {message}', mode='w', backtrace=True, diagnose=True)
    logger.info(Cfg)

    # tensorboard log
    writer = SummaryWriter(log_dir=Cfg.result_dir + '/logs')

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    # initialize network
    model = LLIE()
    model.to(device)


    # set up solver and scheduler
    optimizer = optim.Adam(model.parameters(), lr=Cfg.learning_rate)
    scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[100,200,300], gamma=Cfg.scheduler_gamma)

    # load pretrained for resume
    if Cfg.resume and Cfg.resume_tar is not None:
        model, lastepoch, optimizer, scheduler = utils.load_checkpoint_state(Cfg.resume_tar, device, model,
                                                                            optimizer, scheduler)
        logger.info(f'-----Load pretrained model at epoch {lastepoch}!')
    else:
        lastepoch = 1
        logger.info('------No pretrained model!')

    # preparing dataloader for train
    list_path_train = build_Dataset_list_txt(Cfg.train_input_dir)
    list_path_test = build_Dataset_list_txt(Cfg.test_input_dir)

    train_dataset = Dataset(crop_size=Cfg.ps, list_path=list_path_train, root=Cfg.train_input_dir)
    train_dataloader = DataLoader(train_dataset, batch_size=Cfg.bs, shuffle=True, num_workers=1,
                                  pin_memory=True, persistent_workers=True)

    test_dataset = Dataset(list_path=list_path_test, root=Cfg.test_input_dir, crop_size=0, training=False)
    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=1,
                                 pin_memory=False, persistent_workers=True)

    ssim_high = 0
    psnr_high = 0

    for epoch in tqdm(range(lastepoch, Cfg.training_epoch), desc='Training Epoch:'):
        if os.path.isdir(Cfg.result_dir + '%04d' % epoch):
            continue

        cnt = 0

        mae_loss1_list = []
        ms_ssim_loss_list = []
        all_loss_list = []

        model.train()

        for sample in train_dataloader:
            sample_time = time.perf_counter()
            cnt += Cfg.bs
            in_imgs = sample[0].to(device)
            gt_imgs = sample[1].to(device)
            maskv_images = sample[2].to(device)

            optimizer.zero_grad()
            out_imgs= model(in_imgs,maskv_images)


            mae_loss1 = utils.MAELoss(out_imgs, gt_imgs)
            ms_ssim_loss = utils.MS_SSIMLoss(out_imgs, gt_imgs)
            loss = Cfg.mae_loss_w * mae_loss1  + Cfg.ms_ssim_loss_w * ms_ssim_loss

            loss.backward()
            optimizer.step()

            # loss for the entire epoch
            mae_loss1_list.append(mae_loss1.item())
            ms_ssim_loss_list.append(ms_ssim_loss.item())
            all_loss_list.append(loss.item())

            sample_end_time = time.perf_counter() - sample_time
            logger.info('%d  %d  All_Loss=%.3f  Total_Time=%.3f ' %(epoch, cnt, np.mean(all_loss_list),  sample_end_time,))

        writer.add_scalar('Train/MAE1_Loss', np.mean(mae_loss1_list), epoch)
        writer.add_scalar('Train/MS_SSIM_Loss', np.mean(ms_ssim_loss_list), epoch)
        writer.add_scalar('Train/All_Loss', np.mean(all_loss_list), epoch)

        if epoch % Cfg.test_freq == 0:
            with torch.no_grad():
                eval_time = time.perf_counter()
                model.eval()
                psnr_list, ssim_list = [], []

                for sample in iter(test_dataloader):
                    in_imgs = sample[0].to(device)
                    gt_imgs = sample[1].to(device)
                    maskv_images = sample[2].to(device)
                    out_imgs = model(in_imgs,maskv_images)

                    psnr_list.append(utils.PSNR(out_imgs, gt_imgs).item())
                    ssim_list.append(utils.SSIM(out_imgs, gt_imgs).item())
                    psnr=np.mean(psnr_list)
                    ssim=np.mean(ssim_list)

                    del in_imgs
                    del gt_imgs

                    del maskv_images
                    del out_imgs

                total_eval_time = time.perf_counter() - eval_time

                writer.add_scalar('Test/psnr', np.mean(psnr_list), epoch)
                writer.add_scalar('Test/ssim', np.mean(ssim_list), epoch)
                logger.info('------Total_eval_time=%.3f' % (total_eval_time))

                torch.save(model.state_dict(), os.path.join(Cfg.result_dir, "_Epoch" + '.pth'))

                if ssim > ssim_high:
                    ssim_high = ssim
                    logger.info('---the highest SSIM value is:=%.8f' % (ssim))
                    torch.save(model.state_dict(), os.path.join(Cfg.result_dir, "best_EpochS" + '.pth'))
                if psnr > psnr_high:
                    psnr_high = psnr
                    logger.info('---the highest PSNR value is:=%.8f' % (psnr))
                    torch.save(model.state_dict(), os.path.join(Cfg.result_dir, "best_EpochP" + '.pth'))


        scheduler.step()
    writer.close()


if __name__ == '__main__':
    os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'
    os.environ['CUDA_VISIBLE_DEVICES'] = Cfg.gpu_id
    main()
