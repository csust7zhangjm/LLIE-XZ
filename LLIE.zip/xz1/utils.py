import cv2
import numpy as np
import torch
from pytorch_msssim import ms_ssim, ssim
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

def SSIM(out_image, gt_image):
    out_image = torch.clamp(out_image, min=0.0, max=1.0)
    return ssim(out_image, gt_image, data_range=1, size_average=True)


def PSNR(out_image, gt_image):
    out_image = torch.clamp(out_image, min=0.0, max=1.0)
    mse = torch.mean((out_image - gt_image)**2)
    return 10 * torch.log10(1.0 / mse)

def MAELoss(out_image, gt_image):
    return torch.mean(torch.abs(out_image - gt_image))

def MS_SSIMLoss(out_image, gt_image):
    return 1 - ms_ssim(out_image, gt_image, data_range=1, size_average=True)


def Tensor2OpenCV(img):
    # BxCxHxW (B=1) to HxWxC
    if img.size(dim=0) == 1:
        img = img.squeeze(0)
    img = img.permute(1, 2, 0).cpu().data.numpy()
    img = np.minimum(np.maximum(img, 0), 1)
    img = img * 255
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

    return img

# for checkpoint saving and loading
def load_checkpoint_state(path, device, model, optimizer, scheduler):
    checkpoint = torch.load(path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    epoch = checkpoint["epoch"]
    optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
    return model, epoch, optimizer, scheduler
