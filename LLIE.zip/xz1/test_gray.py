import os
import time
from datetime import datetime
import torchvision.transforms as transforms
import cv2
import numpy as np
import torch
from loguru import logger
from torch.utils.data import DataLoader
from tqdm import tqdm
import lpips
import utils
from cfg import Cfg
from dataloader_gray import Dataset,build_Dataset_list_txt
from model import LLIE

def main():
    # logging to text file
    dt_string = datetime.now().strftime('%d%m%Y_%H%M%S')
    logger.add(f'{Cfg.result_dir}/{dt_string}_test_console.log', format='{time:YYYY-MM-DD at HH:mm:ss} | {level} |  \
                {message}', mode='w', backtrace=True, diagnose=True)

    logger.info(Cfg)

    if Cfg.save_test_image:
        out_img_path = os.path.join(Cfg.result_dir)
        if not os.path.isdir(out_img_path):
            os.makedirs(out_img_path)

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    # initialize network
    model = LLIE()

    # load pretrained for evaluation
    model.load_state_dict(torch.load(".\LOL_LOLv2real.pth"))

    model.to(device)

    # preparing dataloader for test
    list_path_test = build_Dataset_list_txt(Cfg.test_input_dir)

    # logger.info(f'------Evaluated using image size: {Cfg.target_size}!')
    test_dataset = Dataset(list_path=list_path_test, root=Cfg.test_input_dir, crop_size=0, training=False)
    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=0)

    loss_fn = lpips.LPIPS(net='alex').to(device)

    with torch.no_grad():
        eval_time = time.perf_counter()

        model.eval()
        lpips_list = []
        psnr_list, ssim_list = [], []

        for sample in tqdm(test_dataloader, desc='Testing Sample:'):
            in_img = sample[0].to(device)
            gt_img = sample[1].to(device)
            mask = sample[2].to(device)
            in_fn = sample[3]# input filename

            out_img = model(in_img, mask)

            normalize = transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # 归一化到[-1, 1]，公式是：(x-0.5)/0.5
            gt_norm = normalize(gt_img)
            out_norm = normalize(out_img)
            L = loss_fn(out_norm,gt_norm).cpu().numpy()
            lpips_list.append(L)

            psnr_list.append(utils.PSNR(out_img, gt_img).item())
            ssim_list.append(utils.SSIM(out_img, gt_img).item())

            out_img = utils.Tensor2OpenCV(out_img)
            # out_img = cv2.resize(out_img,(600,400))
            if Cfg.save_test_image:
                cv2.imwrite(os.path.join(out_img_path, f'{in_fn[0]}.png'), out_img)


            del in_img
            del gt_img
            del out_img
            del mask


        total_eval_time = time.perf_counter()-eval_time
        logger.info('------Total_eval_time=%.3f' % (total_eval_time))
        logger.info('------LPIPS={}'.format(np.mean(lpips_list)))
        logger.info('------PSNR={}, SSIM={}'.format(np.mean(psnr_list), np.mean(ssim_list)))


if __name__ == '__main__':
    os.environ['CUDA_DEVICE_ORDER'] = 'PCI_BUS_ID'
    os.environ['CUDA_VISIBLE_DEVICES'] = Cfg.gpu_id
    main()
