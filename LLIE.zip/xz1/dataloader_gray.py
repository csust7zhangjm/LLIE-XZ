import os
import random
import time
from PIL import Image
from torch.utils.data import Dataset
from utils import *

def log(string):
    print(time.strftime('%H:%M:%S'), ">> ", string)

def data_augmentation(image, mode):
    if mode == 0:
        # original
        return image
    elif mode == 1:
        # flip up and down
        return np.flipud(image)
    elif mode == 2:
        # rotate counterwise 90 degree
        return np.rot90(image)
    elif mode == 3:
        # rotate 90 degree and flip up and down
        image = np.rot90(image)
        return np.flipud(image)
    elif mode == 4:
        # rotate 180 degree
        return np.rot90(image, k=2)
    elif mode == 5:
        # rotate 180 degree and flip
        image = np.rot90(image, k=2)
        return np.flipud(image)
    elif mode == 6:
        # rotate 270 degree
        return np.rot90(image, k=3)
    elif mode == 7:
        # rotate 270 degree and flip
        image = np.rot90(image, k=3)
        return np.flipud(image)


class CustomDataset(Dataset):
    def __init__(self, datapath):
        super().__init__()
        self.datapath = datapath
        self.img_path = [os.path.join(datapath, f) for f in os.listdir(datapath) if
                        any(filetype in f.lower() for filetype in ['jpeg', 'png', 'jpg', 'bmp'])]
        self.name = [f.split(".")[0] for f in os.listdir(datapath) if any(filetype in 
                    f.lower() for filetype in ['jpeg', 'png', 'jpg', 'bmp'])]
    
    def __len__(self):
        return len(self.img_path)
    
    def __getitem__(self, idx):
        datafiles = self.img_path[idx]
        lr_img = Image.open(datafiles)
        lr_img_hsv = lr_img.convert('HSV')
        _, _, v_image = lr_img_hsv.split()
        # lr_crop = lr_img.resize((1728, 1728), Image.ANTIALIAS)#VV 2304x1728
        # v_crop = v_image.resize((1728, 1728), Image.ANTIALIAS)
        # lr_crop = lr_img.resize((352, 352), Image.ANTIALIAS)#MEF 512x340-389
        # v_crop = v_image.resize((352, 352), Image.ANTIALIAS)
        # lr_crop = lr_img.resize((512,512), Image.ANTIALIAS)#NPE
        # v_crop = v_image.resize((512,512), Image.ANTIALIAS)
        # lr_crop = lr_img.resize((256,256), Image.ANTIALIAS)
        # v_crop = v_image.resize((256,256), Image.ANTIALIAS)#600*400
        # lr_crop = lr_img.resize((480, 480), Image.ANTIALIAS)#DICM 640x480 # LIME
        # v_crop = v_image.resize((480, 480), Image.ANTIALIAS)
        # lr_crop = lr_img.resize((600, 400), Image.ANTIALIAS)#DICM 640x480 # LIME
        # v_crop = v_image.resize((600, 400), Image.ANTIALIAS)
        # maskv = np.asarray(np.expand_dims(v_crop, axis=-1), np.float32)
        # lr_crop = np.asarray(lr_crop, np.float32).transpose((2,0,1)) / 255.
        maskv = np.asarray(np.expand_dims(v_image, axis=-1), np.float32)
        lr_crop = np.asarray(lr_img, np.float32).transpose((2,0,1)) / 255.
        # print(img.shape)
        return lr_crop, maskv, self.name[idx]

def build_Dataset_list_txt(dst_dir):
    log(f"Buliding Dataset list text at {dst_dir}")
    list_path = os.path.join(dst_dir, 'pair_list.csv')
    if os.path.exists(list_path):
        print(f"{list_path} 文件已经存在.")
        return list_path
    #LOL
    lr_dir = os.path.join(dst_dir, 'low')
    hr_dir = os.path.join(dst_dir, 'high')
    img_lr_path = [os.path.join('low', name) for name in os.listdir(lr_dir)]
    img_hr_path = [os.path.join('high', name) for name in os.listdir(hr_dir)]
    #LOLv2
    # lr_dir = os.path.join(dst_dir, 'Low')
    # hr_dir = os.path.join(dst_dir, 'Normal')
    # img_lr_path = [os.path.join('Low', name) for name in os.listdir(lr_dir)]
    # img_hr_path = [os.path.join('Normal', name) for name in os.listdir(hr_dir)]
    #5k,lcdp,MSEC_train_valid
    # lr_dir = os.path.join(dst_dir, 'input')
    # hr_dir = os.path.join(dst_dir, 'gt')
    # img_lr_path = [os.path.join('input', name) for name in os.listdir(lr_dir)]
    # img_hr_path = [os.path.join('gt', name) for name in os.listdir(hr_dir)]
    #MSEC_TEST
    # lr_dir = os.path.join(dst_dir, 'input')
    # hr_dir = os.path.join(dst_dir, 'expert_c_testing_set')
    # img_lr_path = [os.path.join('input', name) for name in os.listdir(lr_dir)]
    # img_hr_path = [os.path.join('expert_c_testing_set', name) for name in os.listdir(hr_dir)]


    # with open(list_path, 'w') as f:
    #     for lr_path, hr_path in zip(img_lr_path, img_hr_path):
    #         f.write(f"{lr_path},{hr_path}\n")

    with open(list_path, 'w') as f:
        for lr_path in img_lr_path:
            lr_name = os.path.basename(lr_path)
            lr_prefix = lr_name[:5]
            for hr_path in img_hr_path:
                hr_name = os.path.basename(hr_path)
                hr_prefix = hr_name[:5]
                if lr_prefix == hr_prefix:
                    f.write(f"{lr_path},{hr_path}\n")
                    break
    log(f"Finish... There are {len(img_lr_path)} pairs...")

    return list_path

class Dataset(Dataset):
    def __init__(self, root, list_path, crop_size, to_RAM=False, training=True):
        super(Dataset,self).__init__()
        self.training = training
        self.to_RAM = to_RAM
        self.root = root
        self.list_path = list_path
        self.crop_size = crop_size
        with open(list_path) as f:
            self.pairs = f.readlines()
        self.files = []
        for pair in self.pairs:
            lr_path, hr_path = pair.split(",")
            hr_path = hr_path[:-1]
            name = lr_path.split("\\")[-1][:-4]
            lr_file = os.path.join(self.root, lr_path)
            hr_file = os.path.join(self.root, hr_path)
            self.files.append({
                "lr": lr_file,
                "hr": hr_file,
                "name": name
            })
        self.data = []
        if self.to_RAM:
            for i, fileinfo in enumerate(self.files):
                name = fileinfo["name"]
                lr_img = Image.open(fileinfo["lr"])
                hr_img = Image.open(fileinfo["hr"])
                self.data.append({
                    "lr": lr_img,
                    "hr": hr_img,
                    "name": name
                })
            log("Finish loading all images to RAM...")
 
    def __len__(self):
        return len(self.files)
 
    def __getitem__(self, idx):
        datafiles = self.files[idx]
 
        '''load the datas'''
        if not self.to_RAM:
            name = datafiles["name"]
            lr_img = Image.open(datafiles["lr"])
            hr_img = Image.open(datafiles["hr"])
            lr_img_hsv = lr_img.convert('HSV')
            _, _, v_image = lr_img_hsv.split()
        else:
            name = self.data[idx]["name"]
            lr_img = self.data[idx]["lr"]
            hr_img = self.data[idx]["hr"]
 
        '''random crop the inputs'''
        if self.crop_size > 0:
            #select a random start-point for croping operation
            h_offset = random.randint(0, lr_img.size[1] - self.crop_size)
            w_offset = random.randint(0, lr_img.size[0] - self.crop_size)
            crop_box = (w_offset, h_offset, w_offset+self.crop_size, h_offset+self.crop_size)
            lr_crop = lr_img
            hr_crop = hr_img
            v_crop = v_image
            if self.training is True:
                lr_crop = lr_img.crop(crop_box)
                hr_crop = hr_img.crop(crop_box)
                v_crop = v_image.crop(crop_box)
                rand_mode = np.random.randint(0, 7)
                lr_crop = data_augmentation(lr_crop, rand_mode)
                hr_crop = data_augmentation(hr_crop, rand_mode)
                v_crop = data_augmentation(v_crop, rand_mode)
        else:
            # lr_crop = lr_img
            # hr_crop = hr_img
            # lr_crop = lr_img.resize((400,608), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((400,608), Image.ANTIALIAS)
            # v_crop = v_image.resize((400,608), Image.ANTIALIAS)
            # lr_crop = lr_img.resize((256,256), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((256,256), Image.ANTIALIAS)
            # v_crop = v_image.resize((256,256), Image.ANTIALIAS)
            # lr_crop = lr_img.resize((576,384), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((576,384), Image.ANTIALIAS)
            # v_crop = v_image.resize((576,384), Image.ANTIALIAS)
            lr_crop = lr_img.resize((512,512), Image.ANTIALIAS)
            hr_crop = hr_img.resize((512,512), Image.ANTIALIAS)
            v_crop = v_image.resize((512,512), Image.ANTIALIAS)
            # lr_crop = lr_img.resize((1088,1088), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((1088,1088), Image.ANTIALIAS)
            # v_crop = v_image.resize((1088,1088), Image.ANTIALIAS)
            # lr_crop = lr_img.resize((1600,1024), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((1600,1024), Image.ANTIALIAS)
            # v_crop = v_image.resize((1600,1024), Image.ANTIALIAS)
            # lr_crop = lr_img.resize((320,320), Image.ANTIALIAS)
            # hr_crop = hr_img.resize((320,320), Image.ANTIALIAS)
            # v_crop = v_image.resize((320,320), Image.ANTIALIAS)
            if self.training is True:
                rand_mode = np.random.randint(0, 7)
                lr_crop = data_augmentation(lr_crop, rand_mode)
                hr_crop = data_augmentation(hr_crop, rand_mode)
                v_crop = data_augmentation(v_crop,rand_mode)

        # # 归一化
        maskv = np.asarray(np.expand_dims(v_crop, axis=-1), np.float32)
        lr_crop = np.asarray(lr_crop, np.float32).transpose((2,0,1)) / 255.
        hr_crop = np.asarray(hr_crop, np.float32).transpose((2,0,1)) / 255.

        return lr_crop, hr_crop, maskv, name

